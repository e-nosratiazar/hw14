package ir.maktab.q2;

public class OutOfRangException extends Exception {
    public OutOfRangException(String message) {
        super(message);
    }
}
