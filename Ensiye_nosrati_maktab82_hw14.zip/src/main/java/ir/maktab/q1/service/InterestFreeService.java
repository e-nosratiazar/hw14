package ir.maktab.q1.service;

public class InterestFreeService {
}
