package ir.maktab.q1.repository;

public class InterestFreeRepository {
}
